#include <iostream>

using namespace std;

struct Node {
    int data;
    Node* next;
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
        head = nullptr;
    }

    void insertAtBeginning(int data) {
        Node* newNode = new Node;
        newNode->data = data;
        newNode->next = head;
        head = newNode;
    }

    void insertAtEnd(int data) {
        Node* newNode = new Node;
        newNode->data = data;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
            return;
        }

        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    void insertAfter(int prevData, int newData) {
        Node* newNode = new Node;
        newNode->data = newData;

        Node* temp = head;
        while (temp != nullptr && temp->data != prevData) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Kh�ng t�m th?y Node c� gi� tr? " << prevData << endl;
            delete newNode;
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    void deleteFromBeginning() {
        if (head == nullptr) {
            cout << "Danh s�ch r?ng" << endl;
            return;
        }

        Node* temp = head;
        head = head->next;
        delete temp;
    }

    void deleteFromEnd() {
        if (head == nullptr) {
            cout << "Danh s�ch r?ng" << endl;
            return;
        }

        if (head->next == nullptr) {
            delete head;
            head = nullptr;
            return;
        }

        Node* temp = head;
        while (temp->next->next != nullptr) {
            temp = temp->next;
        }

        delete temp->next;
        temp->next = nullptr;
    }

    void deleteAfter(int prevData) {
        Node* temp = head;
        while (temp != nullptr && temp->data != prevData) {
            temp = temp->next;
        }

        if (temp == nullptr || temp->next == nullptr) {
            cout << "Kh�ng t�m th?y Node ho?c Node ti?p theo" << endl;
            return;
        }

        Node* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
    }

    void deleteNode(int data) {
        if (head == nullptr) {
            cout << "Danh s�ch r?ng" << endl;
            return;
        }

        if (head->data == data) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;
        while (temp->next != nullptr && temp->next->data != data) {
            temp = temp->next;
        }

        if (temp->next == nullptr) {
            cout << "Kh�ng t�m th?y Node c� gi� tr? " << data << endl;
            return;
        }

        Node* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
    }

    void printList() {
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    void searchNode(int data) {
        Node* temp = head;
        int position = 1;
        while (temp != nullptr) {
            if (temp->data == data) {
                cout << "T�m th?y Node c� gi� tr? " << data << " t?i v? tr� " << position << endl;
                return;
            }
            temp = temp->next;
            position++;
        }
        cout << "Kh�ng t�m th?y Node c� gi� tr? " << data << endl;
    }

    int countNodes() {
        Node* temp = head;
        int count = 0;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

int main() {
    LinkedList list;

    list.insertAtEnd(1);
    list.insertAtEnd(2);
    list.insertAtEnd(3);

    cout << "Danh s�ch hi?n t?i: ";
    list.printList();

    list.insertAtBeginning(0);
    cout << "Danh s�ch sau khi th�m v�o ??u: ";
    list.printList();

    list.insertAfter(2, 4);
    cout << "Danh s�ch sau khi th�m sau Node 2: ";
    list.printList();

    list.deleteFromBeginning();
    cout << "Danh s�ch sau khi x�a ??u: ";
    list.printList();

    list.deleteFromEnd();
    cout << "Danh s�ch sau khi x�a cu?i: ";
    list.printList();

    list.deleteAfter(2);
    cout << "Danh s�ch sau khi x�a sau Node 2: ";
    list.printList();

    list.deleteNode(2);
    cout << "Danh s�ch sau khi x�a Node 2: ";
    list.printList();

    list.searchNode(3);

    cout << "S? Node trong danh s�ch: " << list.countNodes() << endl;

    return 0;
}