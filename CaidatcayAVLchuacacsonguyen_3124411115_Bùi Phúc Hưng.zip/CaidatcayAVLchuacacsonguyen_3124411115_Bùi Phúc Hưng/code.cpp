#include <iostream>
using namespace std;

struct Node {
    int info, chieu_cao;
    Node* pLeft, * pRight;
    Node(int val) : info(val), chieu_cao(1), pLeft(nullptr), pRight(nullptr) {}
};

int layChieuCao(Node* node) {
    return node ? node->chieu_cao : 0;
}

int layHeSoCanBang(Node* node) {
    return node ? layChieuCao(node->pLeft) - layChieuCao(node->pRight) : 0;
}

Node* quayPhai(Node* y) {
    Node* x = y->pLeft;
    Node* T2 = x->pRight;
    x->pRight = y;
    y->pLeft = T2;
    y->chieu_cao = max(layChieuCao(y->pLeft), layChieuCao(y->pRight)) + 1;
    x->chieu_cao = max(layChieuCao(x->pLeft), layChieuCao(x->pRight)) + 1;
    return x;
}

Node* quayTrai(Node* x) {
    Node* y = x->pRight;
    Node* T2 = y->pLeft;
    y->pLeft = x;
    x->pRight = T2;
    x->chieu_cao = max(layChieuCao(x->pLeft), layChieuCao(x->pRight)) + 1;
    y->chieu_cao = max(layChieuCao(y->pLeft), layChieuCao(y->pRight)) + 1;
    return y;
}

Node* chen(Node* node, int info) {
    if (!node) return new Node(info);
    if (info < node->info)
        node->pLeft = chen(node->pLeft, info);
    else if (info > node->info)
        node->pRight = chen(node->pRight, info);
    else
        return node;
    node->chieu_cao = 1 + max(layChieuCao(node->pLeft), layChieuCao(node->pRight));
    int can_bang = layHeSoCanBang(node);
    if (can_bang > 1 && info < node->pLeft->info) return quayPhai(node);
    if (can_bang < -1 && info > node->pRight->info) return quayTrai(node);
    if (can_bang > 1 && info > node->pLeft->info) {
        node->pLeft = quayTrai(node->pLeft);
        return quayPhai(node);
    }
    if (can_bang < -1 && info < node->pRight->info) {
        node->pRight = quayPhai(node->pRight);
        return quayTrai(node);
    }
    return node;
}

Node* giaTriNhoNhat(Node* node) {
    Node* hien_tai = node;
    while (hien_tai->pLeft) hien_tai = hien_tai->pLeft;
    return hien_tai;
}

Node* xoaNode(Node* root, int info) {
    if (!root) return root;
    if (info < root->info)
        root->pLeft = xoaNode(root->pLeft, info);
    else if (info > root->info)
        root->pRight = xoaNode(root->pRight, info);
    else {
        if (!root->pLeft || !root->pRight) {
            Node* tam = root->pLeft ? root->pLeft : root->pRight;
            if (!tam) {
                tam = root;
                root = nullptr;
            }
            else
                *root = *tam;
            delete tam;
        }
        else {
            Node* tam = giaTriNhoNhat(root->pRight);
            root->info = tam->info;
            root->pRight = xoaNode(root->pRight, tam->info);
        }
    }
    if (!root) return root;
    root->chieu_cao = 1 + max(layChieuCao(root->pLeft), layChieuCao(root->pRight));
    int can_bang = layHeSoCanBang(root);
    if (can_bang > 1 && layHeSoCanBang(root->pLeft) >= 0) return quayPhai(root);
    if (can_bang > 1 && layHeSoCanBang(root->pLeft) < 0) {
        root->pLeft = quayTrai(root->pLeft);
        return quayPhai(root);
    }
    if (can_bang < -1 && layHeSoCanBang(root->pRight) <= 0) return quayTrai(root);
    if (can_bang < -1 && layHeSoCanBang(root->pRight) > 0) {
        root->pRight = quayPhai(root->pRight);
        return quayTrai(root);
    }
    return root;
}

void duyetLNR(Node* root) {
    if (root) {
        duyetLNR(root->pLeft);
        cout << root->info << " ";
        duyetLNR(root->pRight);
    }
}

bool timKiem(Node* root, int info) {
    if (!root) return false;
    if (root->info == info) return true;
    if (info < root->info) return timKiem(root->pLeft, info);
    return timKiem(root->pRight, info);
}

int main() {
    Node* root = nullptr;
    root = chen(root, 10);
    root = chen(root, 20);
    root = chen(root, 30);
    root = chen(root, 40);
    root = chen(root, 50);
    root = chen(root, 25);
    cout << "Duyet LNR: ";
    duyetLNR(root);
    cout << endl;
    root = xoaNode(root, 30);
    cout << "Sau khi xoa 30: ";
    duyetLNR(root);
    cout << endl;
    cout << "Tim kiem 25: " << (timKiem(root, 25) ? "Tim thay" : "Khong tim thay") << endl;
    return 0;
}
