#include <iostream>
using namespace std;

// Dinh nghia cau truc cay nhi phan
struct node {
    int info;
    struct node* pLeft;
    struct node* pRight;
};

typedef struct node NODE;
typedef NODE* TREE;

// Tim phan tu nho nhat trong cay
NODE* nhoNhat(TREE Root) {
    if (Root == NULL) return NULL;
    NODE* lc = Root;
    while (lc->pLeft) {
        lc = lc->pLeft;
    }
    return lc;
}

// Tim phan tu lon nhat trong cay
NODE* lonNhat(TREE Root) {
    if (Root == NULL) return NULL;
    NODE* lc = Root;
    while (lc->pRight) {
        lc = lc->pRight;
    }
    return lc;
}

int main() {
    TREE Root = new NODE{ 10, NULL, NULL };
    Root->pLeft = new NODE{ 5, new NODE{3, NULL, NULL}, new NODE{9, new NODE{7, NULL, NULL}, NULL} };
    Root->pRight = new NODE{ 15, new NODE{12, NULL, NULL}, new NODE{18, NULL, new NODE{20, NULL, NULL}} };
    NODE* nho = nhoNhat(Root);
    NODE* lon = lonNhat(Root);
    if (nho) cout << "Phan tu nho nhat: " << nho->info << endl;
    if (lon) cout << "Phan tu lon nhat: " << lon->info << endl;

    return 0;
}
