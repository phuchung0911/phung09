#include <iostream>
using namespace std;

struct BST_NODE {
    int Key;
    int So_lan;
    BST_NODE* Left;
    BST_NODE* Right;
};

struct BST_TREE {
    BST_NODE* pRoot;
};

int DeleteNode(BST_NODE* Root, int x) {
    if (Root == NULL)
        return 0;
    if (Root->Key == x) {
        if (Root->So_lan > 0) {
            Root->So_lan--;
            return 1;
        }
        return 0;
    }
    if (x < Root->Key)
        return DeleteNode(Root->Left, x);
    return DeleteNode(Root->Right, x);
}

void XoaGiaTri(BST_TREE& t, int x) {
    int kq = DeleteNode(t.pRoot, x);
    if (kq == 0)
        cout << "Khong ton tai X" << endl;
    else
        cout << "Xoa thanh cong." << endl;
}

void NLR(BST_NODE* Root) {
    if (Root == NULL)
        return;
    if (Root->So_lan > 0)
        cout << Root->Key << " ";
    NLR(Root->Left);
    NLR(Root->Right);
}

void LietKe(BST_TREE t) {
    NLR(t.pRoot);
}

int main() {
    BST_TREE t;
    t.pRoot = new BST_NODE{ 50, 2, NULL, NULL };
    t.pRoot->Left = new BST_NODE{ 30, 1, NULL, NULL };
    t.pRoot->Right = new BST_NODE{ 70, 1, NULL, NULL };
    t.pRoot->Left->Left = new BST_NODE{ 20, 1, NULL, NULL };
    t.pRoot->Left->Right = new BST_NODE{ 40, 1, NULL, NULL };
    t.pRoot->Right->Left = new BST_NODE{ 60, 1, NULL, NULL };
    t.pRoot->Right->Right = new BST_NODE{ 80, 1, NULL, NULL };

    cout << "Cay truoc khi xoa:" << endl;
    LietKe(t);
    cout << endl;

    XoaGiaTri(t, 50);

    cout << "Cay sau khi xoa:" << endl;
    LietKe(t);
    cout << endl;

    return 0;
}
