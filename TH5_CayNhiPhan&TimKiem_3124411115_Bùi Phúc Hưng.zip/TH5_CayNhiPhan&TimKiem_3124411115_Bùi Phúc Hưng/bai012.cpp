#include <iostream>
using namespace std;

struct Node {
    int info;
    Node* pleft;
    Node* pright;
};

Node* createNode(int info) {
    Node* newNode = new Node();
    newNode->info = info;
    newNode->pleft = newNode->pright = NULL;
    return newNode;
}

void duyetCayRNL(Node* root) {
    if (root != NULL) {
        duyetCayRNL(root->pright);
        cout << root->info << " ";
        duyetCayRNL(root->pleft);
    }
}

int main() {
    Node* root = createNode(10);
    root->pleft = createNode(5);
    root->pright = createNode(15);
    root->pleft->pleft = createNode(3);
    root->pleft->pright = createNode(9);
    root->pright->pleft = createNode(12);
    root->pright->pright = createNode(18);
    root->pleft->pright->pleft = createNode(7);
    root->pright->pright->pright = createNode(20);

    cout << "Duyet cay RNL: ";
    duyetCayRNL(root);
    cout << endl;

    return 0;
}