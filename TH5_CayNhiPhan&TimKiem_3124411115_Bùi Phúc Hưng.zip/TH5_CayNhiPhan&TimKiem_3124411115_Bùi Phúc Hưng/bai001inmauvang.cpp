#include <iostream>
using namespace std;

struct node {
    int info;
    node* pLeft;
    node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

void RemoveAll(TREE& t) {
    if (t == NULL)
        return;
    RemoveAll(t->pLeft);
    RemoveAll(t->pRight);
    delete t;
    t = NULL;
}

int main() {
    TREE t = new NODE{ 50, NULL, NULL };
    t->pLeft = new NODE{ 30, NULL, NULL };
    t->pRight = new NODE{ 70, NULL, NULL };
    t->pLeft->pLeft = new NODE{ 20, NULL, NULL };
    t->pLeft->pRight = new NODE{ 40, NULL, NULL };
    t->pRight->pLeft = new NODE{ 60, NULL, NULL };
    t->pRight->pRight = new NODE{ 80, NULL, NULL };

    RemoveAll(t);
    if (t == NULL)
        cout << "Cay da duoc thu hoi bo nho." << endl;

    return 0;
}
