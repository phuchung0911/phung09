#include <iostream>
using namespace std;

struct Node {
    int info;
    Node* left;
    Node* right;
};

Node* createNode(int info) {
    Node* newNode = new Node();
    newNode->info = info;
    newNode->left = newNode->right = nullptr;
    return newNode;
}

void duyetCayLNR(Node* root) {
    if (root != nullptr) {
        duyetCayLNR(root->left);
        cout << root->info << " ";
        duyetCayLNR(root->right);
    }
}

int main() {
    Node* root = createNode(4);
    root->left = createNode(2);
    root->right = createNode(5);
    root->left->left = createNode(1);
    root->left->right = createNode(3);

    cout << "Duyet cay In-order (LNR): ";
    duyetCayLNR(root);
    cout << endl;

    return 0;
}