#include <iostream>
using namespace std;

// Dinh nghia cau truc cay nhi phan
struct node {
    int info; // Gia tri cua node
    struct node* pLeft; // Con trai
    struct node* pRight; // Con phai
    node(int val) : info(val), pLeft(nullptr), pRight(nullptr) {}
};

typedef struct node NODE;
typedef NODE* TREE;

// Dem so luong node trong cay
int DemNode(TREE Root) {
    if (Root == NULL) return 0;
    return DemNode(Root->pLeft) + DemNode(Root->pRight) + 1;
}

// Tinh tong cac node trong cay
int TongNode(TREE Root) {
    if (Root == NULL) return 0;
    return TongNode(Root->pLeft) + TongNode(Root->pRight) + Root->info;
}

// Tinh trung binh cong cac node trong cay
float TrungBinhCong(TREE Root) {
    int s = TongNode(Root);
    int dem = DemNode(Root);
    if (dem == 0) return 0;
    return (float)s / dem;
}

// Dem so luong node duong
int DemDuong(TREE Root) {
    if (Root == NULL) return 0;
    int a = DemDuong(Root->pLeft);
    int b = DemDuong(Root->pRight);
    return (Root->info > 0) ? (a + b + 1) : (a + b);
}

// Tinh tong cac node duong
int TongDuong(TREE Root) {
    if (Root == NULL) return 0;
    int a = TongDuong(Root->pLeft);
    int b = TongDuong(Root->pRight);
    return (Root->info > 0) ? (a + b + Root->info) : (a + b);
}

// Tinh trung binh cong cac node duong
float TrungBinhDuong(TREE Root) {
    int s = TongDuong(Root);
    int dem = DemDuong(Root);
    if (dem == 0) return 0;
    return (float)s / dem;
}

// Dem so luong node am
int DemAm(TREE Root) {
    if (Root == NULL) return 0;
    int a = DemAm(Root->pLeft);
    int b = DemAm(Root->pRight);
    return (Root->info < 0) ? (a + b + 1) : (a + b);
}

// Tinh tong cac node am
int TongAm(TREE Root) {
    if (Root == NULL) return 0;
    int a = TongAm(Root->pLeft);
    int b = TongAm(Root->pRight);
    return (Root->info < 0) ? (a + b + Root->info) : (a + b);
}

// Tinh trung binh cong cac node am
float TrungBinhCongAm(TREE Root) {
    int s = TongAm(Root);
    int dem = DemAm(Root);
    if (dem == 0) return 0;
    return (float)s / dem;
}

// Tinh ti so giua tong so duong va tong so am
float TinhTySo(TREE Root) {
    int a = TongDuong(Root);
    int b = TongAm(Root);
    if (b == 0) return 0;
    return (float)a / b;
}

int main() {
    // Khoi tao cay nhi phan
    TREE Root = new NODE(5);
    Root->pLeft = new NODE(-3);
    Root->pRight = new NODE(8);
    Root->pLeft->pLeft = new NODE(-7);
    Root->pLeft->pRight = new NODE(2);
    Root->pRight->pLeft = new NODE(6);
    Root->pRight->pRight = new NODE(-4);

    // Xuat ket qua
    cout << "So luong node trong cay: " << DemNode(Root) << endl;
    cout << "Trung binh cong cac node: " << TrungBinhCong(Root) << endl;
    cout << "Trung binh cong cac so duong: " << TrungBinhDuong(Root) << endl;
    cout << "Trung binh cong cac so am: " << TrungBinhCongAm(Root) << endl;
    cout << "Ti so R = a/b: " << TinhTySo(Root) << endl;

    return 0;
}
