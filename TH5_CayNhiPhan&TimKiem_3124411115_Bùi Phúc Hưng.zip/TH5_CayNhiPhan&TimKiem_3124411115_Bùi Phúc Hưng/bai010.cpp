#include <iostream>
#include <fstream>

using namespace std;

struct node {
    float info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

void KhoiTaoCay(TREE& t) {
    t = NULL;
}

void ThemNode(TREE& t, float x) {
    if (t == NULL) {
        NODE* p = new NODE;
        p->info = x;
        p->pLeft = p->pRight = NULL;
        t = p;
    }
    else {
        if (x < t->info)
            ThemNode(t->pLeft, x);
        else if (x > t->info)
            ThemNode(t->pRight, x);
    }
}

void LRN(TREE t, FILE* fp) {
    if (t == NULL)
        return;
    LRN(t->pLeft, fp);
    LRN(t->pRight, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
}

int Xuat(char* filename, TREE t) {
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    LRN(t, fp);
    fclose(fp);
    return 1;
}

int main() {
    TREE t;
    KhoiTaoCay(t);
    ThemNode(t, 10.5);
    ThemNode(t, 5.2);
    ThemNode(t, 15.8);
    ThemNode(t, 3.1);
    ThemNode(t, 7.4);

    if (Xuat("data.out", t))
        cout << "Da ghi vao tap tin thanh cong" << endl;
    else
        cout << "Ghi tap tin that bai" << endl;

    return 0;
}
