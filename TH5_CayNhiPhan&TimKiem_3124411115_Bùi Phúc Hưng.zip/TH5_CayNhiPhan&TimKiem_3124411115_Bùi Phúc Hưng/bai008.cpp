#include <iostream>
#include <cstdio>
using namespace std;

struct node {
    float info;
    struct node* pLeft;
    struct node* pRight;
};

typedef struct node NODE;
typedef NODE* TREE;

void LNR(TREE Root, FILE* fp) {
    if (Root == NULL) return;
    LNR(Root->pLeft, fp);
    fwrite(&Root->info, sizeof(float), 1, fp);
    LNR(Root->pRight, fp);
}

int Xuat(const char* filename, TREE Root) {
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL) return 0;
    LNR(Root, fp);
    fclose(fp);
    return 1;
}

int main() {
    TREE Root = new NODE{ 10.5, NULL, NULL };
    Root->pLeft = new NODE{ 5.2, new NODE{3.1, NULL, NULL}, new NODE{9.8, new NODE{7.4, NULL, NULL}, NULL} };
    Root->pRight = new NODE{ 15.6, new NODE{12.3, NULL, NULL}, new NODE{18.9, NULL, new NODE{20.0, NULL, NULL}} };

    if (Xuat("data.out", Root)) {
        cout << "Xuat du lieu thanh cong!" << endl;
    }
    else {
        cout << "Loi khi mo tap tin!" << endl;
    }

    return 0;
}
