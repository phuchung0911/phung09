#include <iostream>

using namespace std;

struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};

Node* createNode(int info) {
    Node* newNode = new Node();
    newNode->info = info;
    newNode->pLeft = NULL;
    newNode->pRight = NULL;
    return newNode;
}

void chuyenDoiCay(Node* p) {
    if (p == NULL) {
        return;
    }

    Node* temp = p->pLeft;
    p->pLeft = p->pRight;
    p->pRight = temp;

    if (p->pLeft != NULL) {
        temp = p->pLeft->pLeft;
        p->pLeft->pLeft = p->pLeft->pRight;
        p->pLeft->pRight = temp;
    }
}

void inCay(Node* root) {
    if (root != NULL) {
        cout << root->info << " ";
        inCay(root->pLeft);
        inCay(root->pRight);
    }
}

int main() {
    Node* root = createNode(10);
    root->pLeft = createNode(5);
    root->pRight = createNode(15);
    root->pLeft->pLeft = createNode(3);
    root->pLeft->pRight = createNode(9);
    root->pRight->pLeft = createNode(12);
    root->pRight->pRight = createNode(18);
    root->pLeft->pLeft->pLeft = createNode(7);
    root->pRight->pRight->pRight = createNode(20);

    cout << "Cay truoc khi chuyen doi: ";
    inCay(root);
    cout << endl;

    chuyenDoiCay(root);

    cout << "Cay sau khi chuyen doi: ";
    inCay(root);
    cout << endl;

    return 0;
}