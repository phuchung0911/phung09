#include <iostream>
using namespace std;

struct node {
    int info;
    struct node* pLeft;
    struct node* pRight;
};

typedef struct node NODE;
typedef NODE* TREE;

NODE* nhoNhat(TREE Root) {
    if (Root == NULL) return NULL;
    NODE* lc = Root;
    while (lc->pLeft) {
        lc = lc->pLeft;
    }
    return lc;
}

NODE* lonNhat(TREE Root) {
    if (Root == NULL) return NULL;
    NODE* lc = Root;
    while (lc->pRight) {
        lc = lc->pRight;
    }
    return lc;
}

int DemMotCon(TREE Root) {
    if (Root == NULL) return 0;
    if ((Root->pLeft && !Root->pRight) || (!Root->pLeft && Root->pRight))
        return 1 + DemMotCon(Root->pLeft) + DemMotCon(Root->pRight);
    return DemMotCon(Root->pLeft) + DemMotCon(Root->pRight);
}

int DemNode(TREE Root) {
    if (Root == NULL) return 0;
    int a = DemNode(Root->pLeft);
    int b = DemNode(Root->pRight);
    return (a + b + 1);
}

int TongNode(TREE Root) {
    if (Root == NULL) return 0;
    int a = TongNode(Root->pLeft);
    int b = TongNode(Root->pRight);
    return (a + b + Root->info);
}

int main() {
    TREE Root = new NODE{ 10, NULL, NULL };
    Root->pLeft = new NODE{ 5, new NODE{3, NULL, NULL}, new NODE{9, new NODE{7, NULL, NULL}, NULL} };
    Root->pRight = new NODE{ 15, new NODE{12, NULL, NULL}, new NODE{18, NULL, new NODE{20, NULL, NULL}} };

    NODE* nho = nhoNhat(Root);
    NODE* lon = lonNhat(Root);

    if (nho) cout << "Phan tu nho nhat: " << nho->info << endl;
    if (lon) cout << "Phan tu lon nhat: " << lon->info << endl;

    cout << "So nut co mot nhanh con: " << DemMotCon(Root) << endl;
    cout << "So nut trong cay: " << DemNode(Root) << endl;
    cout << "Tong gia tri cac nut trong cay: " << TongNode(Root) << endl;
    return 0;
}
