#include <iostream>
#include <fstream>
using namespace std;

struct node {
    float info;
    node* pLeft;
    node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

void NLR(TREE t, FILE* fp) {
    if (t == NULL)
        return;
    fwrite(&t->info, sizeof(float), 1, fp);
    NLR(t->pLeft, fp);
    NLR(t->pRight, fp);
}

int Xuat(const char* filename, TREE t) {
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    NLR(t, fp);
    fclose(fp);
    return 1;
}

TREE DocCayTuFile(const char* filename) {
    FILE* fp = fopen(filename, "rb");
    if (fp == NULL)
        return NULL;
    TREE t = NULL;
    float x;
    while (fread(&x, sizeof(float), 1, fp)) {
        NODE* newNode = new NODE;
        newNode->info = x;
        newNode->pLeft = newNode->pRight = NULL;

        if (t == NULL) {
            t = newNode;
        }
        else {
            NODE* temp = t;
            NODE* parent = NULL;
            while (temp != NULL) {
                parent = temp;
                if (x < temp->info)
                    temp = temp->pLeft;
                else
                    temp = temp->pRight;
            }
            if (x < parent->info)
                parent->pLeft = newNode;
            else
                parent->pRight = newNode;
        }
    }
    fclose(fp);
    return t;
}

void LNR(TREE t) {
    if (t != NULL) {
        LNR(t->pLeft);
        cout << t->info << " ";
        LNR(t->pRight);
    }
}

int main() {
    TREE t = new NODE{ 50, NULL, NULL };
    t->pLeft = new NODE{ 30, NULL, NULL };
    t->pRight = new NODE{ 70, NULL, NULL };
    t->pLeft->pLeft = new NODE{ 20, NULL, NULL };
    t->pLeft->pRight = new NODE{ 40, NULL, NULL };
    t->pRight->pLeft = new NODE{ 60, NULL, NULL };
    t->pRight->pRight = new NODE{ 80, NULL, NULL };

    const char* filename = "cay_bst.dat";
    Xuat(filename, t);

    TREE t2 = DocCayTuFile(filename);
    cout << "Cay sau khi doc tu file (duyet LNR): ";
    LNR(t2);
    cout << endl;

    return 0;
}
