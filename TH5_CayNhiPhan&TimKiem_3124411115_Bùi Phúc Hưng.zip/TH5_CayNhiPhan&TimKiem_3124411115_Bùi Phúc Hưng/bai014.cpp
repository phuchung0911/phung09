#include <iostream>
using namespace std;

struct nodetree {
    int info;
    struct nodetree* pLeft;
    struct nodetree* pRight;
};
typedef struct nodetree NODETREE;
typedef NODETREE* TREE;

struct nodelist {
    int info;
    struct nodelist* pNext;
};
typedef struct nodelist NODELIST;

struct list {
    NODELIST* pHead;
    NODELIST* pTail;
};
typedef struct list LIST;

void Init(LIST& l) {
    l.pHead = l.pTail = NULL;
}

NODELIST* GetNode(int x) {
    NODELIST* p = new NODELIST;
    if (p == NULL)
        return NULL;
    p->info = x;
    p->pNext = NULL;
    return p;
}

void AddTail(LIST& l, NODELIST* p) {
    if (l.pHead == NULL)
        l.pHead = l.pTail = p;
    else {
        l.pTail->pNext = p;
        l.pTail = p;
    }
}

void RNL(TREE Root, LIST& l) {
    if (Root == NULL)
        return;
    RNL(Root->pRight, l);
    NODELIST* p = GetNode(Root->info);
    if (p != NULL)
        AddTail(l, p);
    RNL(Root->pLeft, l);
}

void BuildList(TREE Root, LIST& l) {
    Init(l);
    RNL(Root, l);
}

void PrintList(LIST l) {
    NODELIST* p = l.pHead;
    while (p != NULL) {
        cout << p->info << " ";
        p = p->pNext;
    }
    cout << endl;
}

int main() {
    TREE t = new NODETREE{ 50, NULL, NULL };
    t->pLeft = new NODETREE{ 30, NULL, NULL };
    t->pRight = new NODETREE{ 70, NULL, NULL };
    t->pLeft->pLeft = new NODETREE{ 20, NULL, NULL };
    t->pLeft->pRight = new NODETREE{ 40, NULL, NULL };
    t->pRight->pLeft = new NODETREE{ 60, NULL, NULL };
    t->pRight->pRight = new NODETREE{ 80, NULL, NULL };

    LIST l;
    BuildList(t, l);
    cout << "Danh sach lien ket giam dan: ";
    PrintList(l);
    return 0;
}
