#include <iostream>
#include <fstream>

using namespace std;

struct node {
    float info;
    struct node* pLeft;
    struct node* pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

void KhoiTaoCay(TREE& t) {
    t = NULL;
}

void ThemNode(TREE& t, float x) {
    if (t == NULL) {
        NODE* p = new NODE;
        p->info = x;
        p->pLeft = p->pRight = NULL;
        t = p;
    }
    else {
        if (x < t->info)
            ThemNode(t->pLeft, x);
        else if (x > t->info)
            ThemNode(t->pRight, x);
    }
}

void NLR(TREE t, FILE* fp) {
    if (t == NULL)
        return;
    fwrite(&t->info, sizeof(float), 1, fp);
    NLR(t->pLeft, fp);
    NLR(t->pRight, fp);
}

int Xuat(const char* filename, TREE t) {
    FILE* fp = fopen(filename, "wb");
    if (fp == NULL)
        return 0;
    NLR(t, fp);
    fclose(fp);
    return 1;
}

void DuyetNLR(TREE t) {
    if (t == NULL)
        return;
    cout << t->info << " ";
    DuyetNLR(t->pLeft);
    DuyetNLR(t->pRight);
}

int main() {
    TREE t;
    KhoiTaoCay(t);
    ThemNode(t, 10.5);
    ThemNode(t, 5.2);
    ThemNode(t, 15.8);
    ThemNode(t, 3.1);
    ThemNode(t, 7.4);

    cout << "Cay duyet theo NLR: ";
    DuyetNLR(t);
    cout << endl;

    if (Xuat("data.out", t))
        cout << "Da ghi vao tap tin thanh cong" << endl;
    else
        cout << "Ghi tap tin that bai" << endl;

    return 0;
}
