#include <iostream>
#include <stack>
#include <queue>
using namespace std;

struct Node {
    int info;
    Node* pLeft;
    Node* pRight;
};

Node* taoNode(int info) {
    Node* node = new Node;
    node->info = info;
    node->pLeft = nullptr;
    node->pRight = nullptr;
    return node;
}

void duyetNLR_khongDeQuy(Node* root) {
    if (root == nullptr) return;
    stack<Node*> s;
    s.push(root);
    while (!s.empty()) {
        Node* node = s.top();
        s.pop();
        cout << node->info << " ";
        if (node->pRight) s.push(node->pRight);
        if (node->pLeft) s.push(node->pLeft);
    }
}

void duyetTheoMuc_khongDeQuy(Node* root) {
    if (root == nullptr) return;
    queue<Node*> q;
    q.push(root);
    while (!q.empty()) {
        Node* node = q.front();
        q.pop();
        cout << node->info << " ";
        if (node->pLeft) q.push(node->pLeft);
        if (node->pRight) q.push(node->pRight);
    }
}

int main() {
    Node* root = taoNode(1);
    root->pLeft = taoNode(2);
    root->pRight = taoNode(3);
    root->pLeft->pLeft = taoNode(4);
    root->pLeft->pRight = taoNode(5);
    root->pRight->pLeft = taoNode(6);
    root->pRight->pRight = taoNode(7);

    cout << "Duyet NLR khong de quy: ";
    duyetNLR_khongDeQuy(root);
    cout << endl;

    cout << "Duyet theo muc khong de quy: ";
    duyetTheoMuc_khongDeQuy(root);
    cout << endl;

    return 0;
}