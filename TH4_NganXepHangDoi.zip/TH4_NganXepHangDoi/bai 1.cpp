﻿#include <iostream>
#include <stack>
#include <string>
#include <cctype>
using namespace std;

#define MAX 100 

class StackInt {
private:
    int arr[MAX];
    int top;
public:
    StackInt() { top = -1; }
    void InitStack() { top = -1; }
    bool IsEmpty() { return top == -1; }
    bool IsFull() { return top == MAX - 1; }
    bool PushStack(int x) {
        if (IsFull()) return false;
        arr[++top] = x;
        return true;
    }
    bool PopStack(int& x) {
        if (IsEmpty()) return false;
        x = arr[top--];
        return true;
    }
    bool PeekStack(int& x) {
        if (IsEmpty()) return false;
        x = arr[top];
        return true;
    }
    void Clear() { top = -1; }
};

struct Node {
    int data;
    Node* next;
};

class LinkedStackInt {
private:
    Node* top;
public:
    LinkedStackInt() { top = nullptr; }
    void InitStack() { top = nullptr; }
    bool IsEmpty() { return top == nullptr; }
    bool PushStack(int x) {
        Node* newNode = new Node{ x, top };
        top = newNode;
        return true;
    }
    bool PopStack(int& x) {
        if (IsEmpty()) return false;
        Node* temp = top;
        x = top->data;
        top = top->next;
        delete temp;
        return true;
    }
    bool PeekStack(int& x) {
        if (IsEmpty()) return false;
        x = top->data;
        return true;
    }
    void Clear() {
        while (!IsEmpty()) {
            int temp;
            PopStack(temp);
        }
    }
};

int ReverseNumber(int num) {
    StackInt stack;
    while (num > 0) {
        stack.PushStack(num % 10);
        num /= 10;
    }
    int reversed = 0, factor = 1;
    while (!stack.IsEmpty()) {
        int digit;
        stack.PopStack(digit);
        reversed += digit * factor;
        factor *= 10;
    }
    return reversed;
}

bool IsPalindrome(const string& str) {
    stack<char> stack;
    int length = str.length();
    for (int i = 0; i < length / 2; i++) {
        stack.push(str[i]);
    }
    for (int i = (length + 1) / 2; i < length; i++) {
        if (stack.top() != str[i]) return false;
        stack.pop();
    }
    return true;
}

string DecimalToBinary(int num) {
    StackInt stack;
    while (num > 0) {
        stack.PushStack(num % 2);
        num /= 2;
    }
    string binary = "";
    while (!stack.IsEmpty()) {
        int bit;
        stack.PopStack(bit);
        binary += to_string(bit);
    }
    return binary;
}

int GetPrecedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

string InfixToPostfix(const string& infix) {
    stack<char> stack;
    string postfix = "";
    for (char ch : infix) {
        if (isdigit(ch)) {
            postfix += ch;
        }
        else if (ch == '(') {
            stack.push(ch);
        }
        else if (ch == ')') {
            while (!stack.empty() && stack.top() != '(') {
                postfix += stack.top();
                stack.pop();
            }
            stack.pop();
        }
        else {
            while (!stack.empty() && GetPrecedence(stack.top()) >= GetPrecedence(ch)) {
                postfix += stack.top();
                stack.pop();
            }
            stack.push(ch);
        }
    }
    while (!stack.empty()) {
        postfix += stack.top();
        stack.pop();
    }
    return postfix;
}

int EvaluatePostfix(const string& postfix) {
    stack<int> stack;
    for (char ch : postfix) {
        if (isdigit(ch)) {
            stack.push(ch - '0');
        }
        else {
            int b = stack.top(); stack.pop();
            int a = stack.top(); stack.pop();
            switch (ch) {
            case '+': stack.push(a + b); break;
            case '-': stack.push(a - b); break;
            case '*': stack.push(a * b); break;
            case '/': stack.push(a / b); break;
            }
        }
    }
    return stack.top();
}

int main() {
    cout << "Dao so 1234: " << ReverseNumber(1234) << endl;
    cout << "Xau 'madam' doi xung: " << (IsPalindrome("madam") ? "Yes" : "No") << endl;
    cout << "So 10 doi sang nhi phan: " << DecimalToBinary(10) << endl;
    string infix = "3+5*2";
    string postfix = InfixToPostfix(infix);
    cout << "Bieu thuc hau to: " << postfix << endl;
    cout << "Gia tri bieu thuc: " << EvaluatePostfix(postfix) << endl;
    return 0;
}
