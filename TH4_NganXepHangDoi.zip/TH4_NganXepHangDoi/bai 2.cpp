#include <iostream>
#include <climits>

using namespace std;

// (a) Cai dat CTDL QueueInt va LinkedQueueInt

// 1. QueueInt (su dung mang)
class QueueInt {
private:
    int* arr;
    int capacity;
    int front;
    int rear;
    int count;

public:
    QueueInt(int size) {
        capacity = size;
        arr = new int[size];
        front = 0;
        rear = -1;
        count = 0;
    }

    ~QueueInt() {
        delete[] arr;
    }

    bool isEmpty() {
        return (count == 0);
    }

    bool isFull() {
        return (count == capacity);
    }

    void enqueue(int item) {
        if (isFull()) {
            cout << "Hang doi day!" << endl;
            return;
        }

        rear = (rear + 1) % capacity;
        arr[rear] = item;
        count++;
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Hang doi rong!" << endl;
            return INT_MIN;
        }

        int item = arr[front];
        front = (front + 1) % capacity;
        count--;
        return item;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Hang doi rong!" << endl;
            return INT_MIN;
        }

        return arr[front];
    }

    void clear() {
        front = 0;
        rear = -1;
        count = 0;
    }
};

// 2. LinkedQueueInt (su dung danh sach lien ket)
class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = nullptr;
    }
};

class LinkedQueueInt {
private:
    Node* front;
    Node* rear;

public:
    LinkedQueueInt() {
        front = nullptr;
        rear = nullptr;
    }

    ~LinkedQueueInt() {
        clear();
    }

    bool isEmpty() {
        return (front == nullptr);
    }

    void enqueue(int item) {
        Node* newNode = new Node(item);

        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        }
        else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Hang doi rong!" << endl;
            return INT_MIN;
        }

        int item = front->data;
        Node* temp = front;
        front = front->next;
        delete temp;

        if (front == nullptr) {
            rear = nullptr;
        }

        return item;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Hang doi rong!" << endl;
            return INT_MIN;
        }

        return front->data;
    }

    void clear() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
        rear = nullptr;
    }
};

// (b) Ung dung hang doi de xep lich cap mua nam/nu
void dancePairing(LinkedQueueInt& males, LinkedQueueInt& females) {
    cout << "Cac cap mua:" << endl;
    while (!males.isEmpty() && !females.isEmpty()) {
        int male = males.dequeue();
        int female = females.dequeue();
        cout << "Nam: " << male << ", Nu: " << female << endl;
    }

    if (!males.isEmpty()) {
        cout << "Con lai " << males.peek() << " nam chua co cap." << endl;
    }
    else if (!females.isEmpty()) {
        cout << "Con lai " << females.peek() << " nu chua co cap." << endl;
    }
}

// (c) Ung dung hang doi de cai thuat toan RadixSort
void radixSort(int arr[], int n) {
    int maxVal = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > maxVal) {
            maxVal = arr[i];
        }
    }

    int exp = 1;
    while (maxVal / exp > 0) {
        LinkedQueueInt buckets[10];

        for (int i = 0; i < n; i++) {
            buckets[(arr[i] / exp) % 10].enqueue(arr[i]);
        }

        int index = 0;
        for (int i = 0; i < 10; i++) {
            while (!buckets[i].isEmpty()) {
                arr[index++] = buckets[i].dequeue();
            }
        }

        exp *= 10;
    }
}

int main() {
    // Vi du su dung hang doi mang
    QueueInt queueArray(5);
    queueArray.enqueue(1);
    queueArray.enqueue(2);
    queueArray.enqueue(3);

    cout << "Phan tu dau hang doi mang: " << queueArray.peek() << endl;
    cout << "Lay ra tu hang doi mang: " << queueArray.dequeue() << endl;

    // Vi du su dung hang doi danh sach lien ket
    LinkedQueueInt queueList;
    queueList.enqueue(4);
    queueList.enqueue(5);
    queueList.enqueue(6);

    cout << "Phan tu dau hang doi danh sach lien ket: " << queueList.peek() << endl;
    cout << "Lay ra tu hang doi danh sach lien ket: " << queueList.dequeue() << endl;

    // Vi du xep lich cap mua
    LinkedQueueInt males;
    males.enqueue(1);
    males.enqueue(3);
    males.enqueue(5);

    LinkedQueueInt females;
    females.enqueue(2);
    females.enqueue(4);
    females.enqueue(6);
    females.enqueue(7);

    dancePairing(males, females);

    // Vi du Radix Sort
    int arr[] = { 170, 45, 75, 90, 802, 24, 2, 66 };
    int n = sizeof(arr) / sizeof(arr[0]);

    radixSort(arr, n);

    cout << "Mang sau khi sap xep Radix Sort: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}