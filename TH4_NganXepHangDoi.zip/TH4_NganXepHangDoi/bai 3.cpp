#include <iostream>
#include <stack>

using namespace std;

// ===============================
// (a) Fibonacci: De quy va khu de quy
// ===============================
// De quy
int Fibonacci_DeQuy(int n) {
    if (n <= 1) return n;
    return Fibonacci_DeQuy(n - 1) + Fibonacci_DeQuy(n - 2);
}

// Khu de quy (dung Stack)
int Fibonacci_KhuDeQuy(int n) {
    if (n <= 1) return n;
    stack<int> s;
    s.push(0);
    s.push(1);
    for (int i = 2; i <= n; i++) {
        int first = s.top(); s.pop();
        int second = s.top();
        s.push(first);
        s.push(first + second);
    }
    return s.top();
}

// ===============================
// (b) Dao nguoc so: De quy va khu de quy
// ===============================
// De quy
int DaoNguoc_DeQuy(int n, int rev = 0) {
    if (n == 0) return rev;
    return DaoNguoc_DeQuy(n / 10, rev * 10 + n % 10);
}

// Khu de quy (dung Stack)
int DaoNguoc_KhuDeQuy(int n) {
    stack<int> s;
    while (n > 0) {
        s.push(n % 10);
        n /= 10;
    }
    int rev = 0, mul = 1;
    while (!s.empty()) {
        rev += s.top() * mul;
        s.pop();
        mul *= 10;
    }
    return rev;
}

// ===============================
// (c) Thap Ha Noi: De quy va khu de quy
// ===============================
// De quy
void ThapHaNoi_DeQuy(int n, char tu, char den, char trungGian) {
    if (n == 1) {
        cout << "Chuyen dia " << n << " tu " << tu << " sang " << den << endl;
        return;
    }
    ThapHaNoi_DeQuy(n - 1, tu, trungGian, den);
    cout << "Chuyen dia " << n << " tu " << tu << " sang " << den << endl;
    ThapHaNoi_DeQuy(n - 1, trungGian, den, tu);
}

// Khu de quy (dung Stack)
struct DiChuyen {
    int n;
    char tu, den, trungGian;
    DiChuyen(int _n, char _tu, char _den, char _trungGian) : n(_n), tu(_tu), den(_den), trungGian(_trungGian) {}
};

void ThapHaNoi_KhuDeQuy(int n) {
    stack<DiChuyen> s;
    s.push(DiChuyen(n, 'A', 'C', 'B'));

    while (!s.empty()) {
        DiChuyen hienTai = s.top();
        s.pop();

        if (hienTai.n == 1) {
            cout << "Chuyen dia 1 tu " << hienTai.tu << " sang " << hienTai.den << endl;
        }
        else {
            s.push(DiChuyen(hienTai.n - 1, hienTai.trungGian, hienTai.den, hienTai.tu));
            s.push(DiChuyen(1, hienTai.tu, hienTai.den, hienTai.trungGian));
            s.push(DiChuyen(hienTai.n - 1, hienTai.tu, hienTai.trungGian, hienTai.den));
        }
    }
}

// ===============================
// Ham main
// ===============================
int main() {
    int n;

    // Tinh so Fibonacci
    cout << "Nhap so n de tinh Fibonacci: ";
    cin >> n;
    cout << "Fibonacci de quy: " << Fibonacci_DeQuy(n) << endl;
    cout << "Fibonacci khu de quy: " << Fibonacci_KhuDeQuy(n) << endl;

    // Dao nguoc so
    cout << "\nNhap so nguyen can dao nguoc: ";
    cin >> n;
    cout << "So dao nguoc (de quy): " << DaoNguoc_DeQuy(n) << endl;
    cout << "So dao nguoc (khu de quy): " << DaoNguoc_KhuDeQuy(n) << endl;

    // Bai toan thap Ha Noi
    cout << "\nNhap so dia trong bai toan thap Ha Noi: ";
    cin >> n;
    cout << "Thap Ha Noi (de quy):\n";
    ThapHaNoi_DeQuy(n, 'A', 'C', 'B');

    cout << "\nThap Ha Noi (khu de quy):\n";
    ThapHaNoi_KhuDeQuy(n);

    return 0;
}
