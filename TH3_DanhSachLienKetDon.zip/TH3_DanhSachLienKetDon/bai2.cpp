#include <iostream>
#include <cstring>
using namespace std;

struct SinhVien {
    char hoTen[50];
    char diaChi[70];
    char lop[10];
    int khoa;

    void nhap() {
        cout << "Nh?p h? t�n: ";
        cin.ignore();  
        cin.getline(hoTen, 50);
        cout << "Nh?p ??a ch?: ";
        cin.getline(diaChi, 70);
        cout << "Nh?p l?p: ";
        cin.getline(lop, 10);
        cout << "Nh?p kh�a: ";
        cin >> khoa;
    }

    void xuat() const {
        cout << "H? t�n: " << hoTen << ", ??a ch?: " << diaChi
            << ", L?p: " << lop << ", Kh�a: " << khoa << endl;
    }
};

bool soSanhTheoTen(const SinhVien& sv1, const SinhVien& sv2) {
    return strcmp(sv1.hoTen, sv2.hoTen) < 0;
}

bool soSanhTheoDiaChi(const SinhVien& sv1, const SinhVien& sv2) {
    return strcmp(sv1.diaChi, sv2.diaChi) < 0;
}

bool soSanhTheoLop(const SinhVien& sv1, const SinhVien& sv2) {
    return strcmp(sv1.lop, sv2.lop) < 0;
}

bool soSanhTheoKhoa(const SinhVien& sv1, const SinhVien& sv2) {
    return sv1.khoa < sv2.khoa;
}

class Node {
public:
    SinhVien data;
    Node* next;
    Node(SinhVien sv) : data(sv), next(nullptr) {}
};

class ListSV {
private:
    Node* head;

public:
    ListSV() : head(nullptr) {}

    bool isEmpty() const {
        return head == nullptr;
    }

    void add(SinhVien sv) {
        Node* newNode = new Node(sv);
        if (isEmpty()) {
            head = newNode;
        }
        else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    void removeByName(const char* ten) {
        if (isEmpty()) {
            cout << "Danh s�ch r?ng.\n";
            return;
        }

        if (strcmp(head->data.hoTen, ten) == 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* current = head;
        while (current->next && strcmp(current->next->data.hoTen, ten) != 0) {
            current = current->next;
        }

        if (current->next == nullptr) {
            cout << "Kh�ng t�m th?y sinh vi�n c� t�n \"" << ten << "\".\n";
        }
        else {
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
    }

    void removeByAddress(const char* diaChi) {
        if (isEmpty()) {
            cout << "Danh s�ch r?ng.\n";
            return;
        }

        if (strcmp(head->data.diaChi, diaChi) == 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* current = head;
        while (current->next && strcmp(current->next->data.diaChi, diaChi) != 0) {
            current = current->next;
        }

        if (current->next == nullptr) {
            cout << "Kh�ng t�m th?y sinh vi�n c� ??a ch? \"" << diaChi << "\".\n";
        }
        else {
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
    }

    void addList(ListSV& otherList) {
        if (isEmpty()) {
            head = otherList.head;
        }
        else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = otherList.head;
        }
    }

    void selectionSort(bool (*compare)(const SinhVien&, const SinhVien&)) {
        if (isEmpty()) return;

        Node* current = head;
        while (current) {
            Node* minNode = current;
            Node* temp = current->next;
            while (temp) {
                if (compare(temp->data, minNode->data)) {
                    minNode = temp;
                }
                temp = temp->next;
            }
            SinhVien tempData = current->data;
            current->data = minNode->data;
            minNode->data = tempData;
            current = current->next;
        }
    }

    void printList() const {
        if (isEmpty()) {
            cout << "Danh s�ch r?ng.\n";
            return;
        }

        Node* current = head;
        while (current) {
            current->data.xuat();
            current = current->next;
        }
    }

    ~ListSV() {
        Node* current = head;
        while (current) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
};

int main() {
    ListSV listSV;

    cout << "Nh?p 10 sinh vi�n:\n";
    for (int i = 0; i < 10; ++i) {
        SinhVien sv;
        sv.nhap();
        listSV.add(sv);
    }

    cout << "\nDanh s�ch sinh vi�n:\n";
    listSV.printList();

    listSV.removeByName("Nguyen Van Teo");

    listSV.removeByAddress("Nguyen Van Cu");

    SinhVien svMoi;
    strcpy(svMoi.hoTen, "Tran Thi Mo");
    strcpy(svMoi.diaChi, "25 Hong Bang");
    strcpy(svMoi.lop, "TT0901");
    svMoi.khoa = 2009;
    listSV.add(svMoi);

    cout << "\nDanh s�ch sinh vi�n sau khi thay ??i:\n";
    listSV.printList();

    listSV.selectionSort(soSanhTheoTen);

    cout << "\nDanh s�ch sinh vi�n sau khi s?p x?p theo t�n:\n";
    listSV.printList();

    return 0;
}
