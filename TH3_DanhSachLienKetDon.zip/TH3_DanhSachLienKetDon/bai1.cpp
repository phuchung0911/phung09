#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node(int value) : data(value), next(nullptr) {}
};

class ListInt {
private:
    Node* head;

public:
    ListInt() : head(nullptr) {}

    bool isEmpty() {
        return head == nullptr;
    }

    void add(int value) {
        Node* newNode = new Node(value);
        if (isEmpty()) {
            head = newNode;
        }
        else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    void remove(int value) {
        if (isEmpty()) {
            cout << "Danh s�ch r?ng.\n";
            return;
        }

        if (head->data == value) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* current = head;
        while (current->next && current->next->data != value) {
            current = current->next;
        }

        if (current->next == nullptr) {
            cout << "Kh�ng t�m th?y gi� tr? ?? x�a.\n";
        }
        else {
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
    }

    void addList(ListInt& otherList) {
        if (isEmpty()) {
            head = otherList.head;
        }
        else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = otherList.head;
        }
    }

    void printList() {
        if (isEmpty()) {
            cout << "Danh s�ch r?ng.\n";
            return;
        }

        Node* current = head;
        while (current) {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "None\n";
    }

    ~ListInt() {
        Node* current = head;
        while (current) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
};

int main() {
    ListInt list1;

    cout << "Nh?p 10 s? nguy�n cho danh s�ch ??u ti�n:\n";
    for (int i = 0; i < 10; i++) {
        int value;
        cout << "Nh?p s? th? " << i + 1 << ": ";
        cin >> value;
        list1.add(value);
    }

    cout << "\nDanh s�ch sau khi nh?p 10 s?:\n";
    list1.printList();

    int k;
    cout << "\nNh?p s? k c?n x�a trong danh s�ch: ";
    cin >> k;
    list1.remove(k);

    cout << "\nDanh s�ch sau khi x�a s? k:\n";
    list1.printList();

    ListInt list2;
    cout << "\nNh?p 5 s? nguy�n cho danh s�ch th? hai:\n";
    for (int i = 0; i < 5; i++) {
        int value;
        cout << "Nh?p s? th? " << i + 1 << ": ";
        cin >> value;
        list2.add(value);
    }

    list1.addList(list2);

    cout << "\nDanh s�ch th? nh?t sau khi th�m danh s�ch th? hai:\n";
    list1.printList();

    return 0;
}
